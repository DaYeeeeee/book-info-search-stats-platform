from mongodb_connect import get_db

db = get_db()
readers = db["readers"]

def find_readers(query={}):
    return list(readers.find(query))

def count_by_college():
    return list(readers.aggregate([
        {"$group": {"_id": "$college", "count": {"$sum": 1}}}
    ]))

def level_distribution():
    return list(readers.aggregate([
        {"$group": {"_id": "$level", "count": {"$sum": 1}}}
    ]))

def get_colleges():
    return readers.distinct("college")
