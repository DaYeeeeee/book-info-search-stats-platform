from mongodb_connect import get_db

db = get_db()
books = db["books"]
logs = db["borrow_logs"]

def category_stats():
    return list(books.aggregate([
        {"$group": {"_id": "$category", "count": {"$sum": 1}, "avgPrice": {"$avg": "$price"}}}
    ]))

def publisher_stats():
    return list(books.aggregate([
        {"$group": {"_id": "$publisher", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}},
        {"$limit": 5}
    ]))

def top_borrowed(n=3):
    return list(books.aggregate([
        {"$sort": {"borrow_count": -1}},
        {"$limit": n},
        {"$project": {"_id": 0, "title": 1, "borrow_count": 1}}
    ]))
