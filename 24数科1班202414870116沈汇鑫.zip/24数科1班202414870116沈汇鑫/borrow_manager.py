from mongodb_connect import get_db

db = get_db()
logs = db["borrow_logs"]

def add_borrow(doc):
    result = logs.insert_one(doc)
    print("借阅记录插入成功，_id:", result.inserted_id)

def return_book(book_isbn, reader_card):
    result = logs.update_many(
        {"book_isbn": book_isbn, "reader_card": reader_card, "status": "借阅中"},
        {"$set": {"status": "已归还"}}
    )
    print("归还记录更新数:", result.modified_count)

def find_borrows(query={}):
    return list(logs.find(query))

def overdue_query(due_date):
    return list(logs.find({
        "return_date": {"$lt": due_date},
        "status": "借阅中"
    }))
