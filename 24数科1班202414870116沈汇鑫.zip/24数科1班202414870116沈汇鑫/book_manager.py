from mongodb_connect import get_db

db = get_db()
books = db["books"]

def add_book(doc):
    result = books.insert_one(doc)
    print("插入成功，_id:", result.inserted_id)

def add_books(docs):
    result = books.insert_many(docs)
    print("批量插入成功，数量:", len(result.inserted_ids))

def find_books(query={}):
    return list(books.find(query))

def find_book(query):
    return books.find_one(query)

def update_book(query, update):
    result = books.update_one(query, update)
    print("修改文档数:", result.modified_count)

def delete_book(query):
    result = books.delete_one(query)
    print("删除文档数:", result.deleted_count)

def delete_books(query):
    result = books.delete_many(query)
    print("批量删除文档数:", result.deleted_count)
