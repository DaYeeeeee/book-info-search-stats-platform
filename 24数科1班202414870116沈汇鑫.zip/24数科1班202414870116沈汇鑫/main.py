from book_manager import find_books, add_book, update_book, delete_book
from reader_manager import find_readers, count_by_college, get_colleges
from borrow_manager import find_borrows, add_borrow, return_book
from stat_manager import category_stats, publisher_stats, top_borrowed

def show_menu():
    print("\n===图书情报检索与统计平台===")
    print("1. 查询图书")
    print("2. 新增图书")
    print("3. 更新图书库存")
    print("4. 删除图书")
    print("5. 查询读者")
    print("6. 按学院统计读者")
    print("7. 查询借阅记录")
    print("8. 分类统计")
    print("9. 出版社统计Top5")
    print("10. 借阅次数Top3")
    print("0. 退出")

def main():
    while True:
        show_menu()
        choice = input("请选择：").strip()
        if choice == "1":
            results = find_books()
            print(f"共{len(results)}本图书")
            for b in results:
                print(b.get("title"), b.get("category"), b.get("price"))
        elif choice == "2":
            title = input("书名：")
            isbn = input("ISBN：")
            add_book({"title": title, "isbn": isbn})
        elif choice == "3":
            isbn = input("ISBN：")
            n = int(input("调整数量（正数增加/负数减少）："))
            update_book({"isbn": isbn}, {"$inc": {"stock": n}})
        elif choice == "4":
            isbn = input("ISBN：")
            delete_book({"isbn": isbn})
        elif choice == "5":
            results = find_readers()
            print(f"共{len(results)}位读者")
            for r in results:
                print(r.get("name"), r.get("college"), r.get("level"))
        elif choice == "6":
            for item in count_by_college():
                print(item["_id"], item["count"], "人")
        elif choice == "7":
            results = find_borrows()
            print(f"共{len(results)}条借阅记录")
            for r in results:
                print(r.get("book_isbn"), r.get("reader_card"), r.get("status"))
        elif choice == "8":
            for item in category_stats():
                print(item["_id"], item["count"], "本")
        elif choice == "9":
            for item in publisher_stats():
                print(item["_id"], item["count"], "本")
        elif choice == "10":
            for item in top_borrowed():
                print(item["title"], item["borrow_count"], "次")
        elif choice == "0":
            print("已退出")
            break
        else:
            print("无效选项")

if __name__ == "__main__":
    main()
