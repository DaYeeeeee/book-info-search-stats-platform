
def get_db():
    client = MongoClient(
    host="127.0.0.1",
    port=27017,
    username="libWriter",
    password="Write123456",
    authSource="library"
)
    return client["library"]

if __name__ == "__main__":
    db = get_db()
    print("连接成功，集合列表：", db.list_collection_names())
